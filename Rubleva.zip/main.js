function serchOn() {
    var serch = document.getElementsByClassName("none");
    var i;
    for (i = 0; i < serch.length; i++) {
        serch[i].style.display = "block";
    }
}

